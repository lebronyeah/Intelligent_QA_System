'''
实现beautiful的读取文档结构功能
'''

import bs4
import re
from time import sleep
from bs4 import BeautifulSoup

dir_name = 'E:\软件杯\support.huaweicloud.com'
filename = 'support.huaweicloud.com_ais_faq_zh-cn_topic_0071378733.html'
direct = dir_name + '/' + filename


def readfile(filename):
    question = ''
    answer_final = ''
    with open(filename,'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f,'html.parser')
        contents = soup.find_all('div', attrs={"class":"crumbs"})
        for content in contents:
            question = content.span.string
        print('question:'+question)
        answers = soup.find_all('div', id="body1502347684004")
        answer = answers[0]
        # print(answer.children)
        # print(answer)
        for child in answer.children:
            if(child.name == 'p'):
                answer_final += child.string
            if(child.name == 'ol'):
                # answer_final += child.li.p.string
                for grandchild in child.children:
                    # print(grandchild.name)
                    if(grandchild.name == 'li'):
                        # print(grandchild.p.string)
                        answer_final += str(grandchild.p.string)
                    else:
                        pass
        print('answer:' + answer_final)
                    # print(??grand)
        # print(answer_final)
        # for answer in answers:
        #     # if(answer.name == 'p'):
        #     #     answer_final += answer.string 
        #     # print(answer.name)
        #     print(answer)

def main():
    readfile(direct)
    # print(str)

if __name__ == '__main__':
    main()
from pyltp import SentenceSplitter
from pyltp import Segmentor
from pyltp import Postagger
from pyltp import SementicRoleLabeller
from pyltp import NamedEntityRecognizer
from pyltp import Parser

def filter(sentence,file_out):
    if '？' in sentence:
        file_out.write(sentence + '\n')
    else:
        n_number = 0
        v_number = 0
        words = segmentor(sentence)
        posttages = postagger(words)
        for posttage in posttages:
            if posttage == 'n':
                n_number += 1
            elif posttage == 'v':
                v_number += 1
        if(n_number >= 2 and v_number >= 1):
            # print('n:' + str(n_number))
            # print('v:'+ str(v_number))
            file_out.write(sentence + '\n')
        else:
            print('不满足条件')
    # if '？' in sentence:
    #     file_out.write(sentence)
    
        

#筛选有用数据
def filter_label(List):
    useless_labels = ['简介','帮助中心','概览','产品简介','价格说明','快速入门','FAQ','用户指南','概述','购买指南',
    ]
    use_list = []
    for label in List:
        if label not in useless_labels:
            use_list.append(label)
    return use_list

def segmentor(sentence):
    segment = Segmentor()
    segment.load('D:\\Ltp\\ltp_data_v3.4.0\\cws.model')
    words = segment.segment(sentence)
    words_list = list(words)
    segment.release()
    return words_list

def postagger(words):
    postagger = Postagger()
    postagger.load('D:\\Ltp\\ltp_data_v3.4.0\\pos.model')
    postags = postagger.postag(words)
    postags_list = list(postags)
    postagger.release()
    return postags_list

def generator(sentence):
    labels = splitor(sentence)
    useful_labels = filter_label(labels)
    last_label = segmentor(useful_labels[-1])
    last_label_postages = postagger(last_label)
    if(
        last_label[0] == '什么' or
        last_label[0] == '怎么' or
        last_label[0] == '如何'
    ):
        str = ''
        print(str.join(last_label))

    elif last_label_postages[0] is 'v':
        if(len(last_label_postages) == 1):
            print('怎么' + last_label[0] + useful_labels[0] + '?')
        else:
            if '和' not in last_label:
                 str = ''
                 print('怎么' + last_label.pop(0) + useful_labels[0] + '的' + str.join(last_label))
            else:
                last_label_postages.reverse()
                index_of_last_v = len(last_label_postages) - last_label_postages.index('v')
                last_label_postages.reverse()
                str = ''
                print('怎么' + str.join(last_label[:index_of_last_v])  + '的' + str.join(last_label[index_of_last_v:]) + '？')

def main():
    out = open('./software/my/tmp.txt', 'w', encoding='utf-8')
    questions = open('./tmp.txt', 'r', encoding='utf-8')
    for question in questions.readlines():
        filter(question,out)


if __name__ == '__main__':
    main()
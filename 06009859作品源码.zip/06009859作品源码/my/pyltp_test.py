# -*- coding: utf-8 -*-

from pyltp import SentenceSplitter
from pyltp import Segmentor
from pyltp import Postagger
from pyltp import SementicRoleLabeller
from pyltp import NamedEntityRecognizer
from pyltp import Parser



#进行分句子
def sentence_splitter(sentence):
    sentences = SentenceSplitter.split(sentence)
    return '\n'.join(sentences)

#进行分词
def segmentor(sentence):
    segmentor = Segmentor()
    segmentor.load('D:\\Ltp\\ltp_data_v3.4.0\\cws.model')
    words = segmentor.segment(sentence)
    words_list = list(words)
    segmentor.release()
    return words_list

#进行词性标注
def posttagger(words):
    posttagger = Postagger()    #初始化实例
    posttagger.load('D:\\Ltp\\ltp_data_v3.4.0\\pos.model')
    posttags = posttagger.postag(words)
    for word, posttag in zip(words, posttags):
        print(word+'/'+posttag)
    posttagger.release()
    print('*************************************')
    return posttags

#命名实体识别
########命名实体类型规则#########
#   人名(Nh)  地名(Ns)  机构名(Ni)
#   ltp采用了BIESO标注体系
#   B表示实体开始词
#   I表示实体中间词
#   E表示实体结束词
#   S表示单独构成实体
#   O表示不构成实体
def NER(words, posttags):
    recognizer = NamedEntityRecognizer()
    recognizer.load('D:\\Ltp\\ltp_data_v3.4.0\\ner.model')
    netags = recognizer.recognize(words, posttags)
    i = 0
    for word, netag in zip(words, netags):
        i = i + 1
        print(str(i) + '|' + word + '|' + netag)
    recognizer.release()
    print('*************************************')
    return netags

#依存语义分析
def parse(words, posttags):
    parse = Parser()
    parse.load('D:\\Ltp\\ltp_data_v3.4.0\\parser.model')
    arcs = parse.parse(words, posttags)
    i = 0
    for word, arc in zip(words, arcs):
        i = i + 1
        print('NO.' +str(i) + '| ' +str(arc.head) +'|'+ str(arc.relation))
    parse.release()
    print('*************************************')
    return arcs

#角色标注
def role_label(words, posttags, netags, arcs):
    srl = SementicRoleLabeller()
    srl.load('D:\\Ltp\\ltp_data_v3.4.0\\pisrl_win.model')
    roles = srl.label(words, posttags, netags, arcs)
    for role in roles:
        print(role.index, "".join(
            ["%s:(%d,%d)" % (arg.name, arg.range.start, arg.range.end) for arg in role.arguments]
        ))
    srl.release()

def generator(sentence):
    is_list = ['服务','挂钩','头','事件']
    has_list = ['方法','说明']
    words = segmentor(sentence)
    word_list = list(words)
    postages = posttagger(words)
    postages_list = list(postages)
    if '？' in word_list:
        print(''.join(word_list))
    else:
        if(postages_list[0] == 'v'):
            print('如何' + ''.join(word_list)+'？')
        elif(word_list[-1] in is_list):
            print('什么是' + ''.join(word_list) + '？')
        elif(word_list[-1] in has_list):
            print(''.join(word_list) + '有哪些' + '？')

def main():
    # sentence = '帮助中心 > 云容器引擎 > 用户指南 > Docker基础知识 > Docker基本概念'
    sentence = '开通人工智能服务'
    sentences = sentence_splitter(sentence)
    print(sentences)
    words = segmentor(sentence)
    # for word in words_list:
    #     print(word)
    # print(sentences)
    posttags = posttagger(words)
    netags = NER(words, posttags)
    print(netags)
    arcs = parse(words, posttags)
    # role_label(words, posttags, netags, arcs)         #贼耗内存啊啊啊啊啊啊啊
    print('###############################')
    generator(sentence)

if __name__ == "__main__":
    main()

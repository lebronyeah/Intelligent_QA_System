'''
根据html页面生成问题
'''

import os
import bs4
from bs4 import BeautifulSoup
from pyltp import SentenceSplitter
from pyltp import Segmentor
from pyltp import Postagger
from pyltp import SementicRoleLabeller
from pyltp import NamedEntityRecognizer
from pyltp import Parser

#分割标签
def splitor(sentence):
    labels_list = list(sentence.split('>'))
    return labels_list

#筛选有用数据
def filter_label(List):
    useless_labels = ['简介','帮助中心','概览','产品简介','价格说明','快速入门','FAQ','用户指南','概述','购买指南']
    use_list = []
    for label in List:
        if label not in useless_labels:
            use_list.append(label)

    return use_list

def segmentor(sentence):
    segment = Segmentor()
    segment.load('D:\\Ltp\\ltp_data_v3.4.0\\cws.model')
    words = segment.segment(sentence)
    words_list = list(words)
    segment.release()
    return words_list

def postagger(words):
    postagger = Postagger()
    postagger.load('D:\\Ltp\\ltp_data_v3.4.0\\pos.model')
    postags = postagger.postag(words)
    postags_list = list(postags)
    postagger.release()
    return postags_list

def generator(sentence):
    labels = splitor(sentence)
    useful_labels = filter_label(labels)
    last_label = segmentor(useful_labels[-1])
    last_label_postages = postagger(last_label)
    if(
        last_label[0] == '什么' or
        last_label[0] == '怎么' or
        last_label[0] == '如何'
    ):
        str = ''
        print(str.join(last_label))

    elif last_label_postages[0] is 'v':
        if(len(last_label_postages) == 1):
            print('怎么' + last_label[0] + useful_labels[0] + '?')
        else:
            if '和' not in last_label:
                 str = ''
                 print('怎么' + last_label.pop(0) + useful_labels[0] + '的' + str.join(last_label))
            else:
                last_label_postages.reverse()
                index_of_last_v = len(last_label_postages) - last_label_postages.index('v')
                last_label_postages.reverse()
                str = ''
                print('怎么' + str.join(last_label[:index_of_last_v])  + '的' + str.join(last_label[index_of_last_v:]) + '？')

def read_file(filename):
    question = ''
    out_file = 'tmp.txt'
    out = open(out_file, 'w', encoding='utf-8')
    with open(filename, 'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f, 'html.parser')
        contents = soup.find_all('div', attrs={"class":"crumbs"})
        for content in contents:
            question = str(content.span.string)
            # print(question)
    return question

def get_question(dir_name):
    questions = []
    for root, firs, files in os.walk(dir_name):
        for file in files:
            question = read_file(dir_name + '/' + file)
            questions.append(question)
    return questions



def main():
    # sentence = '帮助中心 > 云容器引擎 > 用户指南 > FAQ > 访问和使用DWS？'
    # # labels_list = splitor(sentence)
    # # use_list = filter_label(labels_list)
    # # last_label = use_list[-1]
    # # last_label = segmentor(last_label)
    # # print(last_label)
    # # print(last_label.pop(0))
    # # print(use_list.reserse())
    # generator(sentence)
    out_file = 'tmp.txt'
    out = open(out_file, 'w', encoding='utf-8')
    dir_name = 'E:\软件杯\support.huaweicloud.com'
    string = 'hello'
    # print(questions)
    for question in questions:
        out.write(question + '\n')
    out.close()
    # out = open('tmp.txt', 'w', encoding='utf-8')
    # for i in range(300):
    #     out.write(string + str(i) + '\n')
    # out.close()



if __name__ == '__main__':
    main()

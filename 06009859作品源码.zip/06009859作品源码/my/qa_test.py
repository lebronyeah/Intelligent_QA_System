import jieba.posseg as pseg
from pyltp import Segmentor
from pyltp import Postagger

def segmentor(sentence):
    segmentor = Segmentor()
    segmentor.load('D:\\Ltp\\ltp_data_v3.4.0\\cws.model')
    words = segmentor.segment(sentence)
    words_list = list(words)
    segmentor.release()
    return words_list

def posttagger(words):
    posttagger = Postagger()    #初始化实例
    posttagger.load('D:\\Ltp\\ltp_data_v3.4.0\\pos.model')
    posttags = posttagger.postag(words)
    posttagger.release()
    return posttags

# def single_info_line_changing_jieba(sentence):
#     words = pseg.cut(sentence)
#     words_list = list(words)
#     for word, flag in words_list:
#         if flag == 'v':
#             print(word+ '什么?')
#             break;
#         print(word, end='')

def single_info_line_changing_ltp(sentence):
    words = segmentor(sentence)
    posttags = posttagger(words)
    question = ''
    for word, posttag in zip(words, posttags):
        if posttag == 'v':
            word = word + '什么?'
            question = question + word
            break;
        if (posttag != 'd' and posttag != 'u'):
            # print(word, end='')
            question = question + word
    return question


qa = {}
sentence = "阿里云也提供了API接口方便您管理云服务器ECS"

questions = []
question = single_info_line_changing_ltp(sentence)
questions.append(question)
print(questions)
answers = []
answers.append(sentence)
print(answers)

for question, answer in zip(questions, answers):
    qa[question] = answer



# print(question)
print(str(qa))

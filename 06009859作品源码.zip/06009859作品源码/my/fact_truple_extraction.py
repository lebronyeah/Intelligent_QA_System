import codecs
import re 
from pyltp import SentenceSplitter
from pyltp import Segmentor
from pyltp import Postagger
from pyltp import NamedEntityRecognizer

#进行分句子
def sentence_splitter(sentence):
    sentences = SentenceSplitter.split(sentence)
    return '\n'.join(sentences)

#进行分词
def segmentor(sentence):
    segmentor = Segmentor()
    segmentor.load('D:\\Ltp\\ltp_data_v3.4.0\\cws.model')
    words = segmentor.segment(sentence)
    words_list = list(words)
    segmentor.release()
    return words_list


def postagger(words):
    postagger = Postagger()
    postagger.load('D:\\Ltp\\ltp_data_v3.4.0\\pos.model')
    posttags = postagger.postag(words)
    postags = list(posttags)
    postagger.release()
    return postags

def NER(words, postags):
    recognizer = NamedEntityRecognizer()
    recognizer.load('D:\\Ltp\\ltp_data_v3.4.0\\ner.model')
    nerttags = recognizer.recognize(words, postags)
    nertags = list(nerttags)
    return nertags

with open('./software/my/out_file.txt','w',encoding='utf-8') as f:
# out_file = codecs.open('out.file.txt','r',encoding='utf-8')
    sentence1 = '机器学习(Machine Learning, ML)是一门多领域交叉学科，涉及概率论、统计学、逼近论、凸分析、算法复杂度理论等多门学科。专门研究计算机怎样模拟或实现人类的学习行为，以获取新的知识或技能，重新组织已有的知识结构使之不断改善自身的性能。'
    # 获得一个句子的集合
    sentences = sentence_splitter(sentence1)
    # sentences = list(sentences)
    sentences = sentences.split('\n')
    # print(sentences)
    # 处理每个句子
    for sent in sentences:
        words = segmentor(sent)
        postags = postagger(words)
        nertags = NER(words, postags)
        for word,nertag in zip(words,nertags):
            result = word+nertag
            f.write(result)


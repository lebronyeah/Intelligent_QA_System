'''
通过解析html页面来获得问题
'''

import os 
import re
import bs4
from bs4 import BeautifulSoup



def read_file(filename):
    question = ''
    out_file = 'tmp.txt'
    out = open(out_file, 'w', encoding='utf-8')
    with open(filename, 'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f, 'html.parser')
        contents = soup.find_all('div', attrs={"class":"crumbs"})
        for content in contents:
            question = str(content.span.string)
            # print(question)
    return question

def get_question(dir_name):
    questions = []
    for root, firs, files in os.walk(dir_name):
        for file in files:
            question = read_file(dir_name + '/' + file)
            questions.append(question)
    return questions


def main():
    dir_name = 'E:\软件杯\support.huaweicloud.com'
    get_All_File_Content(dir_name)

if __name__ == '__main__':
    main()
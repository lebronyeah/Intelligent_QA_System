import requests
import os
import bs4
from bs4 import BeautifulSoup



def main():
    out = open('first.txt','w', encoding='utf-8')
    with open(r'E:\\软件杯\\support.huaweicloud.com\\developer.huaweicloud.com_ecology-devops.html', 'r', encoding='utf-8') as f:
        for line in f.readlines():
            # print(line)
            out.write(line)
    out.close()
    fout = open('first.txt', 'r', encoding='utf-8')
    # print(type(fout))
    soup = BeautifulSoup(fout, "html.parser")
    h3s = soup.find_all('h3')
    # print(type(h3s))
    # print(h3s)
    for h3 in h3s:
        h3_list = list(h3)
        print(h3_list)



if __name__ == '__main__':
    main()

from django.conf.urls import url, include


from mydb import views 

import mydb 

urlpatterns = [
    url(r'^mydb/',views.hello),
    url(r'^add/',views.add)
    # url(r'mydb/',views.ReplyDetail,name='reply')
    # url(r'^mydb/$',views.reply)
    # url(r'^/mydb/*$',views.ReplyDetail)
]
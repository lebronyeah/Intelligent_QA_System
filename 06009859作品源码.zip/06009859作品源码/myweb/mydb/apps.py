from django.apps import AppConfig


class MydbConfig(AppConfig):
    name = 'mydb'

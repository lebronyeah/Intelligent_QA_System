from django.shortcuts import render
from django.http import request
from mydb import models
from django.http import HttpResponse
from django.http import JsonResponse

# Create your views here.
def hello(request):
    return render(request, 'mydb/hello.html')
# def ReplyDetail(request):
#     return render(request,'mydb/ReplyDetail.html')
def ajax_list(request):
    a = list(range(100))
    return JsonResponse(a, safe = False)

def add(request):
    a = request.GET['a']
    b = request.GET['b']
    a = int(a)
    b = int(b)
    return HttpResponse(str(a+b))

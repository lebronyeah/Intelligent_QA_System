from django.contrib import admin
from mydb.models import QA

# Register your models here.
class QAAdmin(admin.ModelAdmin):
    list_display = ('question', 'answer')
    list_per_page = 50
#    list_filter = ('question',)
    search_fields = ('question','answer')

admin.site.register(QA, QAAdmin)

# class MyAdminSite(admin.AdminSite):
#     site_header = '智能问答管理系统'
#     site_title = '智能问答'

# admin_site = MyAdminSite(name = 'management')

admin.site.site_header = '智能问答管理系统'
admin.site.site_title = '智能管理'

"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from django.conf.urls import url
from . import view
from mydb import views
import mydb

urlpatterns = [
    path('admin/', admin.site.urls),
    # url(r'^test_ajax$',view.ajax_submit),
    # url(r'mydb/', include('mydb.urls')),
    url(r'^$', view.cover,name = 'answer'),
    url(r'^mydb/',views.hello),
    url(r'^get_ajax/$',view.get_ajax,name='get-ajax'),
    url(r'mydb/add/$', mydb.views.add,name = 'add'),
    url(r'^mydb/ajax_list/$',views.ajax_list,name = 'ajax-list'),
    url(r'^ReplyDetail.html$',view.ReplyDetail),
    url(r'^ReplyDetail_1.html$',view.ReplyDetail1),
    url(r'^ReplyDetail_2.html$',view.ReplyDetail2),
    url(r'^ReplyDetail_3.html$',view.ReplyDetail3)
]

from __future__ import unicode_literals
from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
from mydb import models
from django.core import serializers
import json



def cover(request):
    return render(request, 'cover.html')

def get_ajax(request):
    if request.method == 'POST':
        question = request.POST.get('question')
        answer = serializers.serialize('json',models.QA.objects.filter(question = question))
        print("answer len"+str(len(answer)))
    return JsonResponse(answer, safe=False)


def ReplyDetail(request):
    return render(request, 'ReplyDetail.html')

def ReplyDetail1(request):
    return render(request, 'ReplyDetail_1.html')

def ReplyDetail2(request):
    return render(request, 'ReplyDetail_2.html')

def ReplyDetail3(request):
    return render(request, 'ReplyDetail_3.html')

# def ajax_submit(request):
#     if(request.method == 'POST'):
#         print(request.POST.get("k1"),request.POST.get("k2"))
#         test_list = [request.POST.get("k1"), request.POST.get("k2")]
#         return render(request, 'ajax_text.html',{"data":test_list})
#     else:
#         return render(request, "ajax_text.html")

# def add(request):
#     a = request.GET['a']
#     b = request.GET['b']
#     a = int(a)
#     b = int(b)
#     return HttpResponse(str(a+b))
